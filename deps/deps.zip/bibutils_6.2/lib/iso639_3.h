/*
 * iso639_3.h
 */
#ifndef ISO639_3_H
#define iSO639_3_H

extern char * iso639_3_from_code( const char *code );

#endif
