/*
 * xml_getencoding.h
 *
 * Copyright (c) Chris Putnam 2007-2017
 *
 * Source code released under the GPL version 2
 *
 */
#ifndef XML_GETENCODING_H
#define XML_GETENCODING_H

extern int xml_getencoding( str *s );

#endif
