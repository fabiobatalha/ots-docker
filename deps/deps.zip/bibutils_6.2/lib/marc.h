/*
 * marc.h
 *
 * Copyright (c) Chris Putnam 2008-2017
 *
 * Source code released under the GPL version 2
 *
 */
#ifndef MARC_H
#define MARC_H

extern int marc_findgenre( char *query );
extern int marc_findresource( char *query );

#endif
