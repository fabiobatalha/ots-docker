/*
 * iso639-2 language codes
 */
#ifndef ISO639_2_H
#define ISO639_2_H

extern char * iso639_2_from_code( char *code );
extern char * iso639_2_from_language( char *lang );

#endif
