/*
 * serialno.h
 *
 * Copyright (c) Chris Putnam 2005-2017
 *
 * Source code released under the GPL version 2
 *
 */
#ifndef SERIALNO_H
#define SERIALNO_H
#include <stdio.h>
#include "fields.h"

extern int addsn( fields *info, char *buf, int level );

#endif
